# Detects the face and puts a red box around it

from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import VisualFeatureTypes
from msrest.authentication import CognitiveServicesCredentials
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt

# Connect to API through subscription key and endpoint
subscription_key = "your_real_key_here"
endpoint = "https://your-resource-name.cognitiveservices.azure.com/"

# Authenticate
computervision_client = ComputerVisionClient(endpoint, CognitiveServicesCredentials(subscription_key))

# Load the image
image_path = "images/peopleworking_construction.jpg"
with open(image_path, "rb") as local_image:
    features = [VisualFeatureTypes.faces]
    analysis = computervision_client.analyze_image_in_stream(local_image, features)

# Open the image using PIL to draw on it
image = Image.open(image_path)
draw = ImageDraw.Draw(image)

# Draw bounding boxes around detected faces
if not analysis.faces:
    print("No faces detected.")
else:
    for face in analysis.faces:
        rect = face.face_rectangle
        left = rect.left
        top = rect.top
        right = left + rect.width
        bottom = top + rect.height
        draw.rectangle([left, top, right, bottom], outline="red", width=3)
        draw.text((left, top - 10), f"{face.gender}, {face.age}", fill="red")

    # Show the image with bounding boxes
    plt.imshow(image)
    plt.axis('off')
    plt.title("Detected Faces")
    plt.show()

    # Optionally save it
    image.save("images/peopleworking_faces_annotated.jpg")