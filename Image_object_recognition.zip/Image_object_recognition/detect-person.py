# Detects people/face in the image

# Import necessary libraries 
from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import VisualFeatureTypes
from msrest.authentication import CognitiveServicesCredentials

# Connect to API through subscription key and endpoint
subscription_key = "your_real_key_here"
endpoint = "https://your-resource-name.cognitiveservices.azure.com/"

# Authenticate client
computervision_client = ComputerVisionClient(endpoint, CognitiveServicesCredentials(subscription_key))

# Load image (open once and seek to beginning before each use)
local_image_path = "images/peopleworking.jpg"

# Detect faces
with open(local_image_path, "rb") as image_stream:
    features = [VisualFeatureTypes.faces]
    analysis = computervision_client.analyze_image_in_stream(image_stream, features)

print("Detected faces in image:")
if not analysis.faces:
    print("No faces detected.")
else:
    for face in analysis.faces:
        print(f"Detected a {face.gender or 'Unknown'} face aged {face.age or 'Unknown'}")

# --- Detect objects ---
with open(local_image_path, "rb") as image_stream:
    detect_objects_results_local = computervision_client.detect_objects_in_stream(image_stream)

print("\nDetected objects in image:")
if not detect_objects_results_local.objects:
    print("No objects detected.")
else:
    for obj in detect_objects_results_local.objects:
        print(f"'{obj.object_property}' with confidence {obj.confidence * 100:.2f}%")